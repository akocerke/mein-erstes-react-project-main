This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://nhfonts.etsy.com/listing/1639196014/super-potato-font

Introducing Super Potato: a font so fun, it's practically spudtacular! Imagine a playful blend of fancy dandies and mischievous cartoon characters, all dressed up in spud suits and ready to boogie. 